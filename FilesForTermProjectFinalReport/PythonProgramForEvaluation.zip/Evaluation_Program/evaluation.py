#!/usr/bin/env python
import sys
import os
import os.path
import pandas as pd
import numpy as np
from sklearn.metrics import confusion_matrix
import argparse
from pdb import set_trace

# as per the metadata file, input and output directories are the arguments
parser = argparse.ArgumentParser(description='Parse input and output paths')
parser.add_argument('--input_dir', default='C:/Users/USER/Desktop/Evaluation_Program/ValidationData_public/', type=str, help='the directory of the evaluation data')
parser.add_argument('--submission_dir', default='C:/Users/USER/Desktop/Evaluation_Program/MyRanking/', type=str, help='the directory of the submission file')
parser.add_argument('--output_dir', default='C:/Users/USER/Desktop/Evaluation_Program/EvaluationResult_public/', type=str, help='directory to save the evaluation output')
parser.add_argument('--ref_data', default='quality_response_remapped_public.csv', type=str, help='the ground-truth evaluation file name')
parser.add_argument('--submit_data', default='RankingByLogisticModel.csv', type=str, help='the submission data file name')
args = parser.parse_args()
input_dir = args.input_dir
submission_dir = args.submission_dir
output_dir = args.output_dir
submission_file_name = args.submit_data
reference_file_name = args.ref_data

# make the output dir if not exist
if not os.path.isdir(output_dir):
    os.mkdir(output_dir) 

# read the ground-truth and submission files
truth = pd.read_csv(os.path.join(input_dir, 'quality_response_remapped_public.csv'))
T1 = truth.T1_ALR
T2 = truth.T2_CL
T3 = truth.T3_GF
T4 = truth.T4_MQ
T5 = truth.T5_NS
submission = pd.read_csv(os.path.join(submission_dir, submission_file_name))

# check if the user id and question id in submission and truth match
try:
    l_match = set(truth.left) <= set(submission.QuestionId)
    r_match = set(truth.right) <= set(submission.QuestionId)
    if not l_match:
        message = "left image sequence does not match that the validation file"
        sys.exit(message)
    if not r_match:
        message = "right image sequence does not match that the validation file"
        sys.exit(message)
except:
    message = "problem reading the submission file; does not contain either 'UserId' or 'QuestionId' column"
    sys.exit(message)

# extract ranking
left = list(truth.left)
right = list(truth.right)
if len(left) != len(right):
    message = 'left and right lengths are not the same'
    sys.exit(message)

submission_left = []
submission_right = []
submission_preference = []
for idx in range(len(left)):
    submission_left.append(left[idx])
    submission_right.append(right[idx])
    ranking_left = submission[submission.QuestionId==left[idx]].ranking.values[0]
    ranking_right = submission[submission.QuestionId==right[idx]].ranking.values[0]
    preference = 1 if ranking_left < ranking_right else 2
    submission_preference.append(preference)

assert(submission_left == left)
assert(submission_right == right)

# compute score
score_T1 = np.sum(np.array(submission_preference)==np.array(T1)) / len(truth)
score_T2 = np.sum(np.array(submission_preference)==np.array(T2)) / len(truth)
score_T3 = np.sum(np.array(submission_preference)==np.array(T3)) / len(truth)
score_T4 = np.sum(np.array(submission_preference)==np.array(T4)) / len(truth)
score_T5 = np.sum(np.array(submission_preference)==np.array(T5)) / len(truth)
score = np.max([score_T1, score_T2, score_T3, score_T4, score_T5])

# the scores for the leaderboard must be in a file named "scores.txt"
# https://github.com/codalab/codalab-competitions/wiki/User_Building-a-Scoring-Program-for-a-Competition#directory-structure-for-submissions
with open(os.path.join(output_dir, 'scores_task_3.txt'), 'w') as output_file:
    output_file.write("score:{0}\n".format(score))

# output detailed results
with open(os.path.join(output_dir, 'scores_task_3.html'), 'w') as output_file:
    htmlString = '''<!DOCTYPE html>
                    <html>
                    <p>phase 3: question quality</p>
                    </br>
                    <p>match with instructor 1: {:.4f}</p>
                    <p>match with instructor 2: {:.4f}</p>
                    <p>match with instructor 3: {:.4f}</p>
                    <p>match with instructor 4: {:.4f}</p>
                    <p>match with instructor 5: {:.4f}</p>
                    </html>'''.format(score_T1, score_T2, score_T3, score_T4, score_T5)
    output_file.write(htmlString)